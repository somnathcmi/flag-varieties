from sage.all import *
from polynomial import TPolynomial
from coordinates import PluckerCoordinate
from variety import GrassmannianSubVariety
from monomial import PluckerMonomial

class TPluckerRelation(TPolynomial):
    def __init__(self,variety,ncpair):
        monomials = TPluckerRelation._plucker_relation(variety,ncpair)
        super().__init__(monomials)

    @staticmethod
    def _plucker_relation(v,ncpair):#v is variety
        if v.d != 3:
            raise NotImplementedError("implemented only for d=3")

        def case1(p,q):
            #(i2,j2)
            #(i2,j2,j1)
            #(i3,j2,j1,i2)
            #(i3,j2,i2)
            #(i2,j1)(i3,j2)
            #case1s = [1,-1,1,-1,1,1]
            pc = PluckerCoordinate
            pm = PluckerMonomial
            res = \
            [pm(v, 1,coords=[pc(p),pc(q)]), \
            pm(v,-1,coords=[pc([p[0],q[1],p[2]]),pc([q[0],p[1],q[2]])]),\
            pm(v, 1,coords=[pc([p[0],q[0],p[2]]),pc([q[1],p[1],q[2]])]), \
            pm(v,-1,coords=[pc([p[0],q[0],p[1]]),pc([q[1],p[2],q[2]])]), \
            pm(v, 1,coords=[pc([p[0],q[1],p[1]]),pc([q[0],p[2],q[2]])]), \
            pm(v, 1,coords=[pc([p[0],q[0],q[1]]),pc([p[1],p[2],q[2]])])]
            return res

        def case2(p,q):
            #(i2,j2)
            #(i2,j2,j1)
            #(i3,j2,j1,i2)
            #(i3,j2,i2)
            pc = PluckerCoordinate
            pm = PluckerMonomial

            res = \
            [pm(v, 1,coords=[pc(p),pc(q)]), \
            pm(v,-1,coords=[pc([p[0],p[1],q[2]]),pc([q[0],q[1],p[2]])]), \
            pm(v, 1,coords=[pc([p[0],p[1],q[1]]),pc([q[0],q[2],p[2]])]), \
            pm(v,-1,coords=[pc([p[0],p[1],q[0]]),pc([q[1],q[2],p[2]])])]
            return res

        pc1 = PluckerCoordinate(list(ncpair[0]))
        pc2 = PluckerCoordinate(list(ncpair[1]))
        if not(pc1.is_nc(pc2)):
            raise ValueError("nc pair is not nc")
        i,j = list(ncpair[0]),list(ncpair[1])
        if i[0] > j[0] and i[1] < j[1]:
            return case1(j,i)
        elif i[0] < j[0] and i[1] > j[1]:
            return case1(i,j)
        elif j[0]+j[1]-i[0]-i[1] > 0:
            return case2(i,j)
        elif j[0]+j[1]-i[0]-i[1] < 0:
            return case2(j,i)

