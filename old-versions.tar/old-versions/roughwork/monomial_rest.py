

class TensorMonomial:

    def __init__(self,elem_list)
        self.p = []
        for t in elem_list:
            if not(isinstance(t,TensorBasis)):
                raise ValueError("Not TensorBasis.")
            self.p = self.p + [t]

    @staticmethod
    def get_from_tensor_basis_(t):

        if not(isinstance(t,TensorBasis)):
            raise ValueError("Not TensorBasis.")

        res = TensorMonomial([t])

        return res

    def __mul__(self,other):

        temp = other
        if isinstance(other,TensorBasis)):
            temp = TensorMonomial.get_from_tensor_basis(other)

        elif not(isinstance(other,TensorMonomial)):
            raise ValueError("Not TensorMonomial.")

        res = TensorMonomial([])
        res.p = self.p + temp.p
        return res
