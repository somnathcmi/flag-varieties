from sage.all import *

class TensorBasis:

    def __init__(self,p):
        def check_errors(p1):
            p = deepcopy(p1)
            #p.sort()
            if len(p) == 0:
                raise ValueError("List should be nonempty.")
            for i in range(len(p)):
                if p[i] <= 0:
                    raise ValueError("List should contain positive integers.")

        p = list(p)
        check_errors(p)
        self.p = p

    def __eq__(self,other):
        if not(isinstance(other,TensorBasis)):
            raise TypeError("Not TensorBasis.")
        return self.p == other.p
    def __iter__(self):
        return TensorBasisIterator(self)
    def __len__(self):
        return len(self.p)
    def __getitem__(self,key):
        if key < len(self):
            return self.p[key]
        raise IndexError
    def __setitem__(self,key,value):
        raise AttributeError("cannot modify.")
    def __repr__(self):
        return str(self.p)
    def __str__(self):
        return str(self.p)

    '''Construct list of columns from matrix'''
    @staticmethod
    def get_from_matrix_(mat):

        for x in mat.columns():
            try:
                temp = TensorBasis(x)
                l = l+[temp]
            except:
                print("Matrix column "+str(x)+" contain invalid entries, ommiting it.")
        return l

    def is_zero_as_wedge_basis(self):
        p = list(self)
        p.sort()
        for i in range(1,len(p)):
            if p[i] == p[i-1] :
                return True
        return False

    def weight_vector(self,n=0):
        if n < max(self):
            print(" setting n = maximum in the coordinate.")
            n = max(self)
        v = [0]*n
        for i in self.p:
            v[i-1] = v[i-1]+1
        return vector(v)

    '''Returns sign of permutation required to standardize. Note in case of duplicate entries,
    sign is meaningless.'''
    def get_sign_(self):
        l = len(self)
        q = list(self)
        sign = 1
        for i in range(l):
            for j in range(l-i-1):
                if q[j] > q[j+1]:
                    q[j],q[j+1] = q[j+1],q[j]
                    sign = -1*sign
        #self.p.sort()
        return sign
    def matrix_(self):
        return column_matrix(self)

class SymBasis(TensorBasis):

    def __init__(self,p):
        p.sort()
        super().__init__(p)

    @staticmethod
    def get_from_TensorBasis(t):
        return SymBasis(t.p.sort())

    '''Tableau is semistandard if this order is satisfied.'''
    def __le__(self,other):
        if not(isinstance(other,SymBasis)):
            raise TypeError("Not SymBasis.")
        p1 = list(self)
        p2 = list(other)
        l = len(p2)
        if len(p1)>=l:
            for i in range(l) :
                if p1[i]>p2[i] :
                    return False
            return True
        return False

    def __lt__(self,other):
        if self <= other and self != other:
            return True
        return False

    def is_nc(self,other):
        if self <= other or other <= self:
            return False
        return True

class WedgeBasis(TensorBasis):

    def __init__(self,p):
        self.sign = 0
        super().__init__(p)

    @staticmethod
    def get_from_TensorBasis(t):
        return WedgeBasis(t.p)

    '''Tableau is semistandard if this order is satisfied.'''
    def __le__(self,other):
        if not(isinstance(other,SymBasis)):
            raise TypeError("Not SymBasis.")
        p1 = list(self)
        p2 = list(other)
        l = len(p2)
        if len(p1)>=l:
            for i in range(l) :
                if p1[i]>p2[i] :
                    return False
            return True
        return False

    def __lt__(self,other):
        if self <= other and self != other:
            return True
        return False

    def __bool__(self):
        return self.is_zero_as_wedge_basis()

    def is_nc(self,other):
        if self <= other or other <= self:
            return False
        return True

    def sort_(self):
        self.sign = self.get_sign_()
        self.p.sort()

class TensorBasisIterator:

    def __init__(self,coordinate):
        self.coordinate = coordinate
        self._index = 0
    def __next__(self):
        if self._index < len(self.coordinate):
            self._index = self._index+1
            return self.coordinate[self._index-1]
        raise StopIteration

'''
class TensorCoordinate(TCoordinate):

    def __init__(self,p):
        def check_errors():
            if len(p) == 0 or check_errors(p):
                raise ValueError\
                    ("Invalid tensor coordinate. Expected list of length atleast 1")
            for i in range(len(p)):
                if p[i] <= 0:
                    raise ValueError\
                    ("Invalid tensor coordinate. Expected list of positive integers")
        check_errors()
        super.__init__(p)

    def __repr__(self):
        return "Tensor coordinate "+str(self.p)
    def __str__(self):
        return "Tensor coordinate "+str(self.p)
    def __eq__(self,other):
        if not(isinstance(other,TensorCoordinate)):
            raise TypeError("Expected instance of TensorCoordinaate.")
        if len(self.p)!=len(other.p):
            return False
        for i in range(len(self.p)):
            if self.p[i] != other.p[i]:
                return False
        return True

    use method in plucker coordinate
    def is_zero_as_pluck_coordinate(self):
        def check_errors(l):
            if len(l) == 1:
                False
            for i in range(1,len(l)):
                if l[i] == l[i-1]:
                    return True
            return False

        l = deepcopy(self.p)
        l.sort()
        return check_errors(l)

    def convert_to_pluck_coordinate(self):
        return PluckCoordinate(self.p)

    def convert_to_pluck_coordinate_perm(self):
        pass

    def convert_to_pluck_coordinate_perm_sign(self):

        if self.is_zero_as_pluck_coordinate():
            return 0
        c = self.p
        l = len(c)
        s = 1
        for i in range(l):
            for j in range(l-i-1):
                if c[j] > c[j+1]:
                    c[j],c[j+1] = c[j+1],c[j]
                    s = -1*s

        return s


class TCoordinate:
    def __init__(self,p):
        self.p = p
    def __str__(self):
        return "Coordinate"
    def __iter__(self):
        return TCoordinateIterator(self)
    def __len__(self):
        return len(self.p)
    def __getitem__(self,key):
        if key < len(self):
            return self.p[key]
        raise IndexError
    def __setitem__(self,key,value):
        raise AttributeError("cannot modify TCoordinate.")
    @classmethod
    def from_tensor_coordinate(cls,t):
        def compute_perm(c):
            l = len(c)
            s = 1
            for i in range(l):
                for j in range(l-i-1):
                    if c[j] > c[j+1]:
                        c[j],c[j+1] = c[j+1],c[j]
                        s = -1*s
            return s
        try:
            p = cls(t.p)
            return (compute_perm(t.p),p)
        except ValueError:
            raise ValueError("Tensor is zero as plucker coordinate.")
    def lex_le(self,other):
        if not(isinstance(other,PluckCoordinate)):
            raise TypeError("Expected instance of class PluckCoordinate.")

        for i in range(len(self.p)):
            if self.p[i] != other.p[i]:
                if self.p[i] < other.p[i]:
                    return True
                else:
                    return False

            return True

'''

