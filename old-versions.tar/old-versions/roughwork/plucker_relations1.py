from sage.all import *
from coordinates import TableauColumn
from variety import FlagVariety
from monomial import TableauMonomial
from polynomial import TableauPolynomial

class TableauRelation(TableauPolynomial):
    def __init__(self,variety,ncpair):
        monomials = TPluckerRelation._plucker_relation(variety,ncpair)
        super().__init__(monomials)

    @staticmethod
    def _plucker_relation(v,ncpair):#v is variety
        #if v.d != 3:
        #    raise NotImplementedError("implemented only for d=3")

        def case211(p,q): #len(p)=2,len(q)=2; non-comparable index is 1;
            #following are shuffles required: id; (p0,q0); (p1,q0)
            pc = PluckerCoordinate
            pm = PluckerMonomial

            res = \
            [pm(v, 1,coords=[pc(p),pc(q)]), \
            pm(v,-1,coords=[pc([q[0],p[1]]),pc([p[0]])] ), \
            pm(v,-1,coords=[pc([p[0],q[0]]),pc([p[1]])] )]

            return res

        def case222(p,q): #len(p)=2,len(q)=2; non-comparable index is 2;
            #following are shuffles required: id; (p1,q1); (p1,q0);
            pc = PluckerCoordinate
            pm = PluckerMonomial

            res = \
            [pm(v, 1,coords=[pc(p),pc(q)]), \
            pm(v,-1,coords=[pc([p[0],q[1]]),pc([q[0],p[1]])]),\
            pm(v,-1,coords=[pc([p[0],q[0]]),pc([p[1],q[1]])]), \

            return res

        def case311(p,q): #len(p)=3,len(q)=1; non-comparable index is 1;
            #following are shuffles required: id; (p0,q0); (p1,q0); (p2,q0)
            pc = PluckerCoordinate
            pm = PluckerMonomial

            res = \
            [pm(v, 1,coords=[pc(p),pc(q)]), \
            pm(v,-1,coords=[pc([q[0],p[1],p[2]]),pc([p[0]])] ), \
            pm(v,-1,coords=[pc([p[0],q[0],p[2]]),pc([p[1]])] ), \
            pm(v,-1,coords=[pc([p[0],p[1],q[0]]),pc([p[2]])] ) ]

            return res

        def case321(p,q): #len(p)=3,len(q)=2; non-comparable index is 1;
            #following are shuffles required: id; (p0,q0); (p1,q0); (p2,q0)
            pc = PluckerCoordinate
            pm = PluckerMonomial

            res = \
            [pm(v, 1,coords=[pc(p),pc(q)]), \
            pm(v,-1,coords=[pc([q[0],p[1],p[2]]),pc([p[0],q[1]])] ), \
            pm(v,-1,coords=[pc([p[0],q[0],p[2]]),pc([p[1],q[1]])] ), \
            pm(v,-1,coords=[pc([p[0],p[1],q[0]]),pc([p[2],q[1]])] ) ]

            return res

        def case322(p,q): #len(p)=3,len(q)=2; non-comparable index is 2;
            #following are shuffles required: id; (p1,q1); (p2,q1); (p1,q0); (p2,q0); (p1,q0)(p2,q1)
            pc = PluckerCoordinate
            pm = PluckerMonomial

            res = \
            [pm(v, 1,coords=[pc(p),pc(q)]), \
            pm(v,-1,coords=[pc([p[0],q[1],p[2]]),pc([q[0],p[1]])]),\
            pm(v,-1,coords=[pc([p[0],q[0],p[2]]),pc([p[1],q[1]])]), \
            pm(v,-1,coords=[pc([p[0],p[1],q[1]]),pc([q[0],p[2]])]), \
            pm(v,-1,coords=[pc([p[0],p[1],q[0]]),pc([p[2],q[1]])]), \
            pm(v, 1,coords=[pc([p[0],q[0],q[1]]),pc([p[1],p[2]])])]

            return res

        def case332(p,q): #len(p)=3,len(q)=3; non-comparable index is 2;
            #following are shuffles required: id; (p1,q1); (p2,q1); (p1,q0); (p2,q0); (p1,q0)(p2,q1)
            pc = PluckerCoordinate
            pm = PluckerMonomial

            res = \
            [pm(v, 1,coords=[pc(p),pc(q)]), \
            pm(v,-1,coords=[pc([p[0],q[1],p[2]]),pc([q[0],p[1],q[2]])]),\
            pm(v,-1,coords=[pc([p[0],q[0],p[2]]),pc([p[1],q[1],q[2]])]), \
            pm(v,-1,coords=[pc([p[0],p[1],q[1]]),pc([q[0],p[2],q[2]])]), \
            pm(v,-1,coords=[pc([p[0],p[1],q[0]]),pc([p[2],q[1],q[2]])]), \
            pm(v, 1,coords=[pc([p[0],q[0],q[1]]),pc([p[1],p[2],q[2]])])]

            return res

        def case333(p,q): #len(p)=3,len(q)=3; non-comparable index is 3;
            #following are shuffles required: id; (p2,q0); (p2,q1); (p2,q2)
            pc = PluckerCoordinate
            pm = PluckerMonomial

            res = \
            [pm(v, 1,coords=[pc(p),pc(q)]), \
            pm(v,-1,coords=[pc([p[0],p[1],q[0]]),pc([p[2],q[1],q[2]])] ), \
            pm(v,-1,coords=[pc([p[0],p[1],q[1]]),pc([q[0],p[2],q[2]])] ), \
            pm(v,-1,coords=[pc([p[0],p[1],q[2]]),pc([q[0],q[1],p[2]])] ) ]

            return res

        def get_nc_index(col1,col2):
            pass

        tc1 = TableauColumn(list(ncpair[0]))
        tc2 = TableauColumn(list(ncpair[1]))





        if len(tc1) < len(tc2):
            tc1,tc2 = tc2,tc1

        if not(tc1.is_nc(tc2)):
            raise ValueError("nc pair is not nc")
        i,j = list(tc1),list(tc2)
        if i[0] > j[0]:
            t1,b1 = [],i[0:]
            t2,b2 = i[0:1],i[1:]
            return case0(t1,b1,t2,b2)
        elif i[1] > j[1]:
            t1,b1 = i[0:1],i[1:]
            t2,b2 = i[0:2],i[2:]
            return case1(t1,b1,t2,b2)
        elif i[2] > j[2]:
            t1,b1 = i[0:2],i[2:]
            t2,b2 = i[0:3],[]
            return case2(t1,b1,t2,b2)

