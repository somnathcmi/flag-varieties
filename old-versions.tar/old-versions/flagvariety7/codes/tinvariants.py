from sage.all import *
from sage.interfaces.four_ti_2 import four_ti_2 as fti
from coordinates import TableauColumn
from monomial import TableauMonomial
from variety import FlagVariety

class StudyTInvariantsOnVariety(FlagVariety):

    def __init__(self,shape,n,coordinates):
        super().__init__(shape,n,coordinates)
        self.hb = None
        self.relations = None
        self.hb_factor_info = None
        self.hb_not_factored = None

    def Tinv_monomial_generators(self,deg=None,save_data=False,keep_chains=False):
        """Compute vector representation of T invariant monomials of asked degree."""
        def expand_chain(hb,C):
            ll = len(self)
            if hb.nrows() == 0 or hb.ncols() == 0:
                return None

            t1 = list(hb)
            l = len(t1[0])
            for j in range(ll):
                if j not in C:
                    t1.insert(j,vector([0]*l))
            t1 = matrix(t1)
            if hb != t1.matrix_from_rows(C+[t1.nrows()-1]):
                print("expand_chain() Error: Cross verification failed.")
            return t1

        if self.hb == None:
            chains = self.bo_poset.maximal_chains()
            A = self.get_augmented_matrix()
            HB = []
            for i in range(len(chains)):
                chain = chains[i]
                l = len(chain)

                Ac = A.matrix_from_columns(chain)
                Ac = Ac.augment(A.column(-1))

                hb = (fti.hilbert(Ac)).transpose()
                hb = expand_chain(hb,chain)
                if hb != None:
                    for v in hb.columns():
                        try:
                            HB.index(v)
                        except ValueError:
                            HB.append(v)
            self.hb = HB

        if deg == None:
            return self.hb
        res = []
        for v in self.hb:
            if v[-1] == deg:
                res.append(v)
        return res

    def Tinv_hb_monomials(self,deg=None):
        """Compute tableau representation of T invariant monomials of asked degree"""
        hb = self.Tinv_monomial_generators(deg)
        return [TableauMonomial(self,1,vec = h[:-1]) for h in hb]

