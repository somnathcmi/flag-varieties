from sage.all import *
from coordinates import TableauColumn
from sage.interfaces.four_ti_2 import four_ti_2 as fti

class FlagVariety:

    def __init__(self,shape,n,coordinates):
        def _try_correct_data():
            if n<=0:
                raise ValueError("Invalid n.")

            for i in range(len(shape)-1):#shape is the way Kannan thinks. that is column shape of R1.
                if shape[i]<shape[i+1] or shape[i]<=0 or shape[i]>n:
                    raise ValueError("invalid shape")
            if shape[-1]<=0 or shape[-1]>n:
                raise ValueError("invalid shape")

            res1 = dict.fromkeys(shape)
            for key in res1.keys():
                res1[key] = []
            print(shape)
            for p in coordinates:
                print(p)
                if isinstance(p,TableauColumn) and len(p) in shape:
                    p.sort_()
                    try:
                        res1[len(p)].index(p)
                    except ValueError:
                        if p[-1] <= n:
                            res1[len(p)].append(p)
                else:
                    raise ValueError("Invalid data")

            for key in res1.keys():
                res1[key].sort(key=list)

            return res1

        def _sage_poset():
            B = self.coordinates
            mat = matrix([[Integer(p1<=p2) for p2 in B] for p1 in B])
            return sage.combinat.posets.posets.FinitePoset(DiGraph(mat).transitive_reduction())

        def _get_shape_r():
            l=[]
            tshape = deepcopy(shape)
            while(tshape != []):
                l.append(len(tshape))
                tshape = [item-1 for item in tshape if item!=1]
            return l

        self.coordinate_dict = _try_correct_data()
        self.n = n
        self.shape = shape
        self.shape_r = _get_shape_r()
        self.coordinates = [x for key in sorted(list(self.coordinate_dict),reverse=True) \
                                                    for x in self.coordinate_dict[key]]
        self.bo_poset = _sage_poset()

    def __eq__(self,other):
        #raise NotImplementedError("== operator is not implemented for flag varieties")
        if not(isinstance(other,FlagVariety)) :
            raise TypeError("Expected instance of FlagVariety.")
        if self.shape != other.shape or self.n != other.n or len(self)!=len(other):
            return False
        for i in range(len(self)):
            if self[i] != other[i]:
                return False
        return True

    def get_nc_pairs(self):
        res = []
        for i in range(len(self)):
            for j in range(i+1,len(self)):
                if self[i].is_nc(self[j]):
                    res = res + [[self[i],self[j]]]
        return res
    def indicator_matrix(self):
        return matrix([p.indicator_vector(self.n) for p in self]).transpose()

    def coordinate_type_matrix(self):
        l = list(dict.fromkeys(self.shape))
        l.sort(reverse=True)
        m = matrix([[0]*len(self.coordinates)]*len(l))

        for i in range(len(self.coordinates)):
            j = l.index(len(self.coordinates[i]))
            m[j,i]=1
        return m

    def get_augment_vector(self,split=False):
        l = list(dict.fromkeys(self.shape))
        l.sort(reverse=True)
        v = [-1]*self.n
        w = [0]*len(l)
        for i in range(len(l)):
            w[i]=-1*self.shape.count(l[i])
        if split:
            return (v,w)
        return vector(v+w)

    def get_augmented_matrix(self):
        (v,w) = self.get_augment_vector(True)
        return block_matrix([[self.indicator_matrix(),column_matrix(v)],\
                          [self.coordinate_type_matrix(),column_matrix(w)]],subdivide=True)

    def print_poset(self):
        p = self.bo_poset.plot(element_labels={i:self.coordinates[i] for i in range(len(self))},\
                           element_color="white",element_shape="|", figsize=9,element_size=300)
        return p
    def __add__(self,other):
        raise NotImplementedError
        if not(isinstance(other,FlagVariety)):
            raise TypeError("Invalid data")
        if self.d != other.d or self.n != other.n:
            raise ValueError("Cannot add")
        return FlagVariety(self.d,self.n,self.coordinates+other.coordinates)
    def is_zero(self,p):
        return self.coordinates == []
    def __bool__(self):
        return not(self.is_zero())
    def __iter__(self):
        return VarietyIterator(self)
    def __getitem__(self,key):
        if key < len(self):
            return self.coordinates[key]
        raise IndexError
    def __setitem__(self,key,value):
        raise AttributeError("cannot write")
    def __len__(self):
        return len(self.coordinates)
    def __str__(self):
        return "Flag Variety on coordinates \n"\
                    +str(block_matrix([[column_matrix(range(1,self.n+1)),self.indicator_matrix()]]))

    def __repr__(self):
        return "Flag Variety on coordinates \n"\
                    +str(block_matrix([[column_matrix(range(1,self.n+1)),self.indicator_matrix()]]))
    def __contains__(self,item):
        return item in self.coordinates


class VarietyIterator:
    def __init__(self,variety):
        self.variety = variety
        self._index = 0
    def __next__(self):
        if self._index < len(self.variety):
            self._index = self._index+1
            return self.variety[self._index-1]
        raise StopIteration
