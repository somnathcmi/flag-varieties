from sage.all import *
from sage.interfaces.four_ti_2 import four_ti_2 as fti
from coordinates import TableauColumn
from variety import FlagVariety

class TableauMonomial:
    @staticmethod
    def _try_correct_data1(variety1,coef1,coords1,vec1):
        cres = []
        vres = len(variety1)*[0]
        if coef1 == 0:
            return (0,cres,vres)
        if (coords1 == None and vec1 == None) or not(isinstance(variety1, FlagVariety)):
            raise ValueError("invalid data")
        elif vec1 == None:
            for p in coords1:
                if not(isinstance(p,TableauColumn)):
                    raise ValueError("Invalid coordinate.")
                if p not in variety1 or p.is_zero():
                    return (0,[],vres)
                coef1 = coef1*p.sort_()
                cres.append(p)
            for i in range(len(vres)):
                vres[i] = cres.count(variety1[i])
        else:
            vec1 = vector(vec1)
            if len(vec1)!= len(variety1):
                raise ValueError("Invalid monomial vector")
            for i in vec1:
                if i < 0:
                    raise ValueError("Invalid monomial vector")
            vres = vec1
            for i in range(len(vec1)):
                cres = cres + [variety1[i]]*Integer(vec1[i])
        #cres.sort(key=list)
        return (coef1,cres,vector(vres))
    def __init__(self,variety,coef,coords=None,vec=None):

        (self.coef,self.coords,self.vec) \
                = TableauMonomial._try_correct_data1(variety,coef,coords,vec)
        self.variety = variety

    def __eq__(self,other):
        if not(isinstance(other,TableauMonomial)):
            raise TypeError("Expected instance of class PluckMonomial")
        if any([self.coef!=other.coef, self.variety!=other.variety, \
                                        len(self)!=len(other), self.vec!=other.vec]):
            return False
        return True

    def __mul__(self,other):
        if not(isinstance(other,TableauMonomial)):
            raise TypeError("Expected instance of PluckMonomial")
        if self.variety == other.variety:
            return TableauMonomial(self.variety,self.coef*other.coef,vec=self.vec+other.vec)
        raise ValueError("cannot multiply, variety is not same")

    def __truediv__(self,other):
        if not(isinstance(other,TableauMonomial)):
            raise TypeError("Expected instance of PluckMonomial")
        if self.variety == other.variety:
            return TableauMonomial(self.variety,self.coef*other.coef,vec=self.vec-other.vec)
        raise ValueError("cannot divide, variety is not same")

    def __neg__(self):
        return TableauMonomial(self.variety,-self.coef,vec=self.vec)

    def is_standard(self):
        if self.get_nc_pair() == None:
            return True
        return False

    def get_nc_pair(self):
        tcols = self.coords
        tl = len(tcols)
        ti = 0
        if tl <= 1:
            return None
        while tcols[ti] <= tcols[ti+1]:
            if ti+2 == tl:
                return None
            ti=ti+1
        return (tcols[ti],tcols[ti+1])

    def indicator_matrix(self):
        l = list(self)
        if self.coef == 0:
            return None
        m = [l[0].indicator_vector(self.variety.n)]
        for i in range(1,len(l)):
            v = l[i].indicator_vector(self.variety.n)
            try:
                m.index(v)
            except:
                m.append(v)
        return matrix(m).transpose()


    def weight(self):
        m = self.variety.indicator_matrix()
        v = self.vec
        return m*v

    def __iter__(self):
        return TableauMonomialIterator(self)

    def __len__(self):
        return len(self.coords)

    def __getitem__(self,key):
        if key >= len(self.coords):
            raise IndexError
        return self.coords[key]
    def __setitem__(self,key,value):
        raise AttributeError("read only")
    def __line_list__(self):
        nn = len(self.coords[0])
        m = matrix([list(p)+[0]*(nn-len(p)) for p in self.coords]).transpose()
        m = list(m)
        if self.coef > 0:
            coef = " + "+str(abs(self.coef))
        elif self.coef < 0:
            coef = " - "+str(abs(self.coef))
        n = len(str(coef))
        spaces = ""
        for i in range(n):
            spaces = spaces+" "
        lines = []
        for i in range(len(m)):
            l = "["+str(" ".join(str(x) for x in m[i] if x!= 0))+"]"
            if i == int(len(m)/2):
                lines = lines+[coef+l]
            else:
                lines = lines+[spaces+l]
        return lines
    def __repr__(self):
        return str(self)
    def __str__(self):
        return "\n"+"\n".join(x for x in self.__line_list__())
    def __contains__(self,item):
        return item in self.coords
    def __bool__(self):
        return self.coef != 0

class TableauMonomialIterator:

    def __init__(self,monomial):
        self._index = 0
        self.monomial = monomial
    def __next__(self):
        if self._index < len(self.monomial):
            self._index = self._index+1
            return self.monomial[self._index-1]
        raise StopIteration
