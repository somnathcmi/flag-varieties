from sage.all import *
from coordinates import TableauColumn
from variety import FlagVariety
from monomial import TableauMonomial
from polynomial import TableauPolynomial

class TableauRelation(TableauPolynomial):
    def __init__(self,variety,ncpair):
        monomials = TPluckerRelation._plucker_relation(variety,ncpair)
        super().__init__(monomials)

    @staticmethod
    def _plucker_relation(v,ncpair):#v is variety
        #if v.d != 3:
        #    raise NotImplementedError("implemented only for d=3")

        def case0(p,1):
            #(i1,j1)
            #(i2,j1)
            #(i3,j1)
            pc = PluckerCoordinate
            pm = PluckerMonomial

            res = \
            [pm(v, 1,coords=[pc(t1+b1),pc(t2+b2)]), \
            pm(v,-1,coords=[pc(t1+[t2[0],b1[1],b1[2]]),pc([b1[0],t2[1],t2[2]]+b2)]), \
            pm(v,-1,coords=[pc(t1+[t2[1]]),pc([t2[0],b1[0],t2[2]]+b2)]), \
            pm(v,-1,coords=[pc(t1+[t2[2]]),pc([t2[0],t2[1],b1[0]]+b2)]), \
        def case1(p,q):
            #(i2,j2)
            #(i2,j2,j1)
            #(i3,j2,j1,i2)
            #(i3,j2,i2)
            #(i2,j1)(i3,j2)
            #case1s = [1,-1,1,-1,1,1]
            pc = PluckerCoordinate
            pm = PluckerMonomial
            res = \
            [pm(v, 1,coords=[pc(p),pc(q)]), \
            pm(v,-1,coords=[pc([p[0],q[1],p[2]]),pc([q[0],p[1],q[2]])]),\
            pm(v, 1,coords=[pc([p[0],q[0],p[2]]),pc([q[1],p[1],q[2]])]), \
            pm(v,-1,coords=[pc([p[0],q[0],p[1]]),pc([q[1],p[2],q[2]])]), \
            pm(v, 1,coords=[pc([p[0],q[1],p[1]]),pc([q[0],p[2],q[2]])]), \
            pm(v, 1,coords=[pc([p[0],q[0],q[1]]),pc([p[1],p[2],q[2]])])]
            return res

        def case2(t1,b1,t2,b2):
            #(i2,j2)
            #(i2,j2,j1)
            #(i3,j2,j1,i2)
            #(i3,j2,i2)
            pc = PluckerCoordinate
            pm = PluckerMonomial

            res = \
            [pm(v, 1,coords=[pc(t1+b1),pc(t2+b2)]), \
            pm(v,-1,coords=[pc(t1+[t2[0]]),pc([b1[0],t2[1],t2[2]]+b2)]), \
            pm(v,-1,coords=[pc(t1+[t2[1]]),pc([t2[0],b1[0],t2[2]]+b2)]), \
            pm(v,-1,coords=[pc(t1+[t2[2]]),pc([t2[0],t2[1],b1[0]]+b2)]), \
-
            return res

        tc1 = TableauColumn(list(ncpair[0]))
        tc2 = TableauColumn(list(ncpair[1]))
        if len(tc1) < len(tc2):
            tc1,tc2 = tc2,tc1
        if not(tc1.is_nc(tc2)):
            raise ValueError("nc pair is not nc")
        i,j = list(tc1),list(tc2)
        if i[0] > j[0]:
            t1,b1 = [],i[0:]
            t2,b2 = i[0:1],i[1:]
            return case0(t1,b1,t2,b2)
        elif i[1] > j[1]:
            t1,b1 = i[0:1],i[1:]
            t2,b2 = i[0:2],i[2:]
            return case1(t1,b1,t2,b2)
        elif i[2] > j[2]:
            t1,b1 = i[0:2],i[2:]
            t2,b2 = i[0:3],[]
            return case2(t1,b1,t2,b2)

